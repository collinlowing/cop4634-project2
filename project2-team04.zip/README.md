# cop4634-project2

This program may have extremely long execution times depending on the number of threads and range of numbers to be calculated.
